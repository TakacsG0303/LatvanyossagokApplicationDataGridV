﻿namespace LatvanyossagokApplication
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.textBox_varosnev = new System.Windows.Forms.TextBox();
            this.numericUpDown_varoslakossag = new System.Windows.Forms.NumericUpDown();
            this.button_insertvaros = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button_update_varos = new System.Windows.Forms.Button();
            this.button_delete_varos = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button_deletelatvany = new System.Windows.Forms.Button();
            this.button_updatelatvany = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button_insert_latvany = new System.Windows.Forms.Button();
            this.numericUpDown_latvanyossagar = new System.Windows.Forms.NumericUpDown();
            this.textBox_latvanyossagnev = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_latvanyossagleiras = new System.Windows.Forms.TextBox();
            this.dataGridView_varos = new System.Windows.Forms.DataGridView();
            this.dataGridView_latvanyossag = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_varoslakossag)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_latvanyossagar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_varos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_latvanyossag)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.NavajoWhite;
            this.groupBox1.Controls.Add(this.button_delete_varos);
            this.groupBox1.Controls.Add(this.button_update_varos);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.button_insertvaros);
            this.groupBox1.Controls.Add(this.numericUpDown_varoslakossag);
            this.groupBox1.Controls.Add(this.textBox_varosnev);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(424, 176);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Kiválasztott város adatai";
            // 
            // textBox_varosnev
            // 
            this.textBox_varosnev.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox_varosnev.Location = new System.Drawing.Point(6, 70);
            this.textBox_varosnev.Name = "textBox_varosnev";
            this.textBox_varosnev.Size = new System.Drawing.Size(182, 24);
            this.textBox_varosnev.TabIndex = 0;
            // 
            // numericUpDown_varoslakossag
            // 
            this.numericUpDown_varoslakossag.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown_varoslakossag.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown_varoslakossag.Location = new System.Drawing.Point(194, 70);
            this.numericUpDown_varoslakossag.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.numericUpDown_varoslakossag.Name = "numericUpDown_varoslakossag";
            this.numericUpDown_varoslakossag.Size = new System.Drawing.Size(120, 24);
            this.numericUpDown_varoslakossag.TabIndex = 1;
            // 
            // button_insertvaros
            // 
            this.button_insertvaros.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_insertvaros.Location = new System.Drawing.Point(9, 112);
            this.button_insertvaros.Name = "button_insertvaros";
            this.button_insertvaros.Size = new System.Drawing.Size(103, 33);
            this.button_insertvaros.TabIndex = 2;
            this.button_insertvaros.Text = "Új";
            this.button_insertvaros.UseVisualStyleBackColor = true;
            this.button_insertvaros.Click += new System.EventHandler(this.button_insertvaros_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(6, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 3;
            this.label1.Text = "Város neve:";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(191, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 4;
            this.label2.Text = "Lakosság:";
            // 
            // button_update_varos
            // 
            this.button_update_varos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_update_varos.Location = new System.Drawing.Point(146, 112);
            this.button_update_varos.Name = "button_update_varos";
            this.button_update_varos.Size = new System.Drawing.Size(103, 33);
            this.button_update_varos.TabIndex = 5;
            this.button_update_varos.Text = "Módosítás";
            this.button_update_varos.UseVisualStyleBackColor = true;
            this.button_update_varos.Click += new System.EventHandler(this.button_update_varos_Click);
            // 
            // button_delete_varos
            // 
            this.button_delete_varos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_delete_varos.Location = new System.Drawing.Point(284, 112);
            this.button_delete_varos.Name = "button_delete_varos";
            this.button_delete_varos.Size = new System.Drawing.Size(103, 33);
            this.button_delete_varos.TabIndex = 6;
            this.button_delete_varos.Text = "Törlés";
            this.button_delete_varos.UseVisualStyleBackColor = true;
            this.button_delete_varos.Click += new System.EventHandler(this.button_delete_varos_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.textBox_latvanyossagleiras);
            this.groupBox2.Controls.Add(this.button_deletelatvany);
            this.groupBox2.Controls.Add(this.button_updatelatvany);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.button_insert_latvany);
            this.groupBox2.Controls.Add(this.numericUpDown_latvanyossagar);
            this.groupBox2.Controls.Add(this.textBox_latvanyossagnev);
            this.groupBox2.Location = new System.Drawing.Point(442, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(521, 176);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Kiválasztott látványosság adatai";
            // 
            // button_deletelatvany
            // 
            this.button_deletelatvany.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_deletelatvany.Location = new System.Drawing.Point(284, 112);
            this.button_deletelatvany.Name = "button_deletelatvany";
            this.button_deletelatvany.Size = new System.Drawing.Size(103, 33);
            this.button_deletelatvany.TabIndex = 6;
            this.button_deletelatvany.Text = "Törlés";
            this.button_deletelatvany.UseVisualStyleBackColor = true;
            this.button_deletelatvany.Click += new System.EventHandler(this.button_deletelatvany_Click);
            // 
            // button_updatelatvany
            // 
            this.button_updatelatvany.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_updatelatvany.Location = new System.Drawing.Point(146, 112);
            this.button_updatelatvany.Name = "button_updatelatvany";
            this.button_updatelatvany.Size = new System.Drawing.Size(103, 33);
            this.button_updatelatvany.TabIndex = 5;
            this.button_updatelatvany.Text = "Módosítás";
            this.button_updatelatvany.UseVisualStyleBackColor = true;
            this.button_updatelatvany.Click += new System.EventHandler(this.button_updatelatvany_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(381, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 4;
            this.label3.Text = "Ár:";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(6, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(149, 23);
            this.label4.TabIndex = 3;
            this.label4.Text = "Látványosság neve:";
            // 
            // button_insert_latvany
            // 
            this.button_insert_latvany.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_insert_latvany.Location = new System.Drawing.Point(9, 112);
            this.button_insert_latvany.Name = "button_insert_latvany";
            this.button_insert_latvany.Size = new System.Drawing.Size(103, 33);
            this.button_insert_latvany.TabIndex = 2;
            this.button_insert_latvany.Text = "Új";
            this.button_insert_latvany.UseVisualStyleBackColor = true;
            this.button_insert_latvany.Click += new System.EventHandler(this.button_insert_latvany_Click);
            // 
            // numericUpDown_latvanyossagar
            // 
            this.numericUpDown_latvanyossagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown_latvanyossagar.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDown_latvanyossagar.Location = new System.Drawing.Point(382, 70);
            this.numericUpDown_latvanyossagar.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDown_latvanyossagar.Name = "numericUpDown_latvanyossagar";
            this.numericUpDown_latvanyossagar.Size = new System.Drawing.Size(120, 24);
            this.numericUpDown_latvanyossagar.TabIndex = 1;
            // 
            // textBox_latvanyossagnev
            // 
            this.textBox_latvanyossagnev.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox_latvanyossagnev.Location = new System.Drawing.Point(6, 70);
            this.textBox_latvanyossagnev.Name = "textBox_latvanyossagnev";
            this.textBox_latvanyossagnev.Size = new System.Drawing.Size(182, 24);
            this.textBox_latvanyossagnev.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(194, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(149, 23);
            this.label5.TabIndex = 8;
            this.label5.Text = "Leírás";
            // 
            // textBox_latvanyossagleiras
            // 
            this.textBox_latvanyossagleiras.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox_latvanyossagleiras.Location = new System.Drawing.Point(194, 70);
            this.textBox_latvanyossagleiras.Name = "textBox_latvanyossagleiras";
            this.textBox_latvanyossagleiras.Size = new System.Drawing.Size(182, 24);
            this.textBox_latvanyossagleiras.TabIndex = 7;
            // 
            // dataGridView_varos
            // 
            this.dataGridView_varos.AllowUserToAddRows = false;
            this.dataGridView_varos.AllowUserToDeleteRows = false;
            this.dataGridView_varos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_varos.Location = new System.Drawing.Point(12, 206);
            this.dataGridView_varos.Name = "dataGridView_varos";
            this.dataGridView_varos.ReadOnly = true;
            this.dataGridView_varos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_varos.Size = new System.Drawing.Size(424, 349);
            this.dataGridView_varos.TabIndex = 8;
            this.dataGridView_varos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_varos_CellClick);
            // 
            // dataGridView_latvanyossag
            // 
            this.dataGridView_latvanyossag.AllowUserToAddRows = false;
            this.dataGridView_latvanyossag.AllowUserToDeleteRows = false;
            this.dataGridView_latvanyossag.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_latvanyossag.Location = new System.Drawing.Point(442, 206);
            this.dataGridView_latvanyossag.Name = "dataGridView_latvanyossag";
            this.dataGridView_latvanyossag.ReadOnly = true;
            this.dataGridView_latvanyossag.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_latvanyossag.Size = new System.Drawing.Size(521, 349);
            this.dataGridView_latvanyossag.TabIndex = 9;
            this.dataGridView_latvanyossag.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_latvanyossag_CellClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(975, 567);
            this.Controls.Add(this.dataGridView_latvanyossag);
            this.Controls.Add(this.dataGridView_varos);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Latvanyossagok Application";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_varoslakossag)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_latvanyossagar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_varos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_latvanyossag)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button_delete_varos;
        private System.Windows.Forms.Button button_update_varos;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_insertvaros;
        private System.Windows.Forms.NumericUpDown numericUpDown_varoslakossag;
        private System.Windows.Forms.TextBox textBox_varosnev;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_latvanyossagleiras;
        private System.Windows.Forms.Button button_deletelatvany;
        private System.Windows.Forms.Button button_updatelatvany;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_insert_latvany;
        private System.Windows.Forms.NumericUpDown numericUpDown_latvanyossagar;
        private System.Windows.Forms.TextBox textBox_latvanyossagnev;
        private System.Windows.Forms.DataGridView dataGridView_varos;
        private System.Windows.Forms.DataGridView dataGridView_latvanyossag;
    }
}

