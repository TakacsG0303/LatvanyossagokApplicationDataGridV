﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace LatvanyossagokApplication
{
    static class Program
    {

        public static MySqlConnection conn = null;
        public static MySqlCommand sql = null;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
             MySqlConnectionStringBuilder sb = new MySqlConnectionStringBuilder();
            sb.Server="localhost";
            sb.UserID = "root";
            sb.Password = "";
            sb.Database = "latvanyossagokdb";
            sb.CharacterSet = "utf8";
            sb.Port = 3306;
            conn = new MySqlConnection(sb.ToString());
            try
            {
                conn.Open();
                sql = conn.CreateCommand();

                var cmd = conn.CreateCommand();
                cmd.CommandText = File.ReadAllText("db.sql");
                cmd.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
