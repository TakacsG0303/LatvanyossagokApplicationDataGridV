CREATE TABLE IF NOT EXISTS varosok(
            id INT PRIMARY KEY AUTO_INCREMENT,
            nev VARCHAR(250) NOT NULL,
             lakossag INT NOT NULL
             );

          CREATE TABLE IF NOT EXISTS latvanyossagok(
            id INT PRIMARY KEY AUTO_INCREMENT,
            nev VARCHAR(250) NOT NULL,
            leiras VARCHAR(300) NOT NULL,
            ar INT DEFAULT NULL,
	    varos_id INT NOT NULL,
            FOREIGN KEY (varos_id) REFERENCES varosok(id)
            )