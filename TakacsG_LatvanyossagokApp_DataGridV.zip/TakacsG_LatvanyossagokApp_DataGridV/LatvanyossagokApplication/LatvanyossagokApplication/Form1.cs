﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LatvanyossagokApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       

        private void Form1_Load(object sender, EventArgs e)
        {

            dataGridView_varos.ColumnCount = 3;
            dataGridView_varos.Columns[0].Name = "Id";

            dataGridView_varos.Columns[1].Name = "Nev";
            dataGridView_varos.Columns[1].HeaderText = "Név";

            dataGridView_varos.Columns[2].Name = "Lakossag";
            dataGridView_varos.Columns[2].HeaderText = "Lakosság";




            dataGridView_latvanyossag.ColumnCount = 5;
            dataGridView_latvanyossag.Columns[0].Name = "Id";

            dataGridView_latvanyossag.Columns[1].Name = "Nev";
            dataGridView_latvanyossag.Columns[1].HeaderText = "Név";

            dataGridView_latvanyossag.Columns[2].Name = "Leiras";
            dataGridView_latvanyossag.Columns[2].HeaderText = "Leírás";

            dataGridView_latvanyossag.Columns[3].Name = "Ar";
            dataGridView_latvanyossag.Columns[3].HeaderText = "Ár";


            dataGridView_latvanyossag.Columns[4].Name = "Varos_id";

            DataGridViewvaros_Tabla_Frissit();

            DataGridViewlatvany_Tabla_Frissit();

        }

        private void DataGridViewvaros_Tabla_Frissit()
        {
            dataGridView_varos.Rows.Clear();
            Program.sql.CommandText = "SELECT `id`,`nev`,`lakossag` FROM `varosok`";

            try
            {
                using (MySqlDataReader dr = Program.sql.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        int akt_sor = dataGridView_varos.Rows.Add();
                        dataGridView_varos.Rows[akt_sor].Cells["Id"].Value = dr.GetInt32("id");
                        dataGridView_varos.Rows[akt_sor].Cells["Nev"].Value = dr.GetString("nev");
                        dataGridView_varos.Rows[akt_sor].Cells["Lakossag"].Value = dr.GetInt32("lakossag");
                     
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void DataGridViewlatvany_Tabla_Frissit()
        {
            dataGridView_latvanyossag.Rows.Clear();
            Program.sql.CommandText = "SELECT `id`,`nev`,`leiras`,`ar`,`varos_id` FROM `latvanyossagok`";

            try
            {
                using (MySqlDataReader dr = Program.sql.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        int akt_sor = dataGridView_latvanyossag.Rows.Add();
                        dataGridView_latvanyossag.Rows[akt_sor].Cells["Id"].Value = dr.GetInt32("id");
                        dataGridView_latvanyossag.Rows[akt_sor].Cells["Nev"].Value = dr.GetString("nev");
                        dataGridView_latvanyossag.Rows[akt_sor].Cells["Leiras"].Value = dr.GetString("leiras");
                        dataGridView_latvanyossag.Rows[akt_sor].Cells["Ar"].Value = dr.GetInt32("ar");
                        dataGridView_latvanyossag.Rows[akt_sor].Cells["Varos_id"].Value = dr.GetInt32("varos_id");
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void button_insertvaros_Click(object sender, EventArgs e)
        {
            if (textBox_varosnev.Text.Trim().Equals(""))
            {
                MessageBox.Show("Nem maradhat üresen egy mező sem!");
                return;
            }
            Program.sql.CommandText = "INSERT INTO `varosok`(`id`, `nev`, `lakossag`) VALUES (null,@nev,@lakossag)";
            Program.sql.Parameters.Clear();
            Program.sql.Parameters.AddWithValue("@nev", textBox_varosnev.Text);
            Program.sql.Parameters.AddWithValue("@lakossag",(int) numericUpDown_varoslakossag.Value);
                
            try
            {
                Program.sql.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            DataGridViewvaros_Tabla_Frissit();

        }

        private void button_insert_latvany_Click(object sender, EventArgs e)
        {
            if (textBox_latvanyossagleiras.Text.Trim().Equals("")||textBox_latvanyossagleiras.Text.Trim().Equals(""))
            {
                MessageBox.Show("Nem maradhat üresen egy mező sem!");
                return;
            }
            Program.sql.CommandText = "INSERT INTO `latvanyossagok`(`id`, `nev`, `leiras`, `ar`,`varos_id`) VALUES (null,@nev,@leiras,@ar,@varos_id)";
            Program.sql.Parameters.Clear();
            Program.sql.Parameters.AddWithValue("@nev", textBox_latvanyossagnev.Text);
            Program.sql.Parameters.AddWithValue("@leiras", textBox_latvanyossagleiras.Text);
            Program.sql.Parameters.AddWithValue("@ar", (int)numericUpDown_latvanyossagar.Value);
            Program.sql.Parameters.AddWithValue("@varos_id", (int) 1);

            try
            {
                Program.sql.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            DataGridViewlatvany_Tabla_Frissit();
        }

        private void dataGridView_varos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int akt_sor = dataGridView_varos.SelectedCells[0].RowIndex;
            textBox_varosnev.Text = dataGridView_varos.Rows[akt_sor].Cells["Nev"].Value.ToString();
            numericUpDown_varoslakossag.Value = (int) dataGridView_varos.Rows[akt_sor].Cells["Lakossag"].Value;
        }

        private void dataGridView_latvanyossag_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int akt_sor = dataGridView_latvanyossag.SelectedCells[0].RowIndex;
            textBox_latvanyossagnev.Text = dataGridView_latvanyossag.Rows[akt_sor].Cells["Nev"].Value.ToString();
            textBox_latvanyossagleiras.Text = dataGridView_latvanyossag.Rows[akt_sor].Cells["Leiras"].Value.ToString();
            numericUpDown_latvanyossagar.Value = (int)dataGridView_latvanyossag.Rows[akt_sor].Cells["Ar"].Value;
        }

        private void button_update_varos_Click(object sender, EventArgs e)
        {
            if (textBox_varosnev.Text.Trim().Equals(""))
            {
                MessageBox.Show("Nem maradhat üresen egy mező sem!");
                return;
            }

            Program.sql.CommandText = "UPDATE `varosok` SET `nev`=@nev,`lakossag`=@lakossag WHERE `id`=@id";
            Program.sql.Parameters.Clear();
            Program.sql.Parameters.AddWithValue("@id", (int)dataGridView_varos.SelectedRows[0].Cells["Id"].Value);
            Program.sql.Parameters.AddWithValue("@nev", textBox_varosnev.Text);
            Program.sql.Parameters.AddWithValue("@lakossag", numericUpDown_varoslakossag.Text);

            try
            {
                Program.sql.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            DataGridViewvaros_Tabla_Frissit();
        }

        private void button_updatelatvany_Click(object sender, EventArgs e)
        {
            Program.sql.CommandText = "UPDATE `latvanyossagok` SET `nev`=@nev,`leiras`=@leiras,`ar`=@ar WHERE `id`=@id";
            Program.sql.Parameters.Clear();
            Program.sql.Parameters.AddWithValue("@id", (int)dataGridView_latvanyossag.SelectedRows[0].Cells["Id"].Value);
            Program.sql.Parameters.AddWithValue("@nev", textBox_latvanyossagnev.Text);
            Program.sql.Parameters.AddWithValue("@leiras", textBox_latvanyossagnev.Text);
            Program.sql.Parameters.AddWithValue("@ar", (int)numericUpDown_latvanyossagar.Value);
            try
            {
                Program.sql.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            DataGridViewlatvany_Tabla_Frissit();
        }

        private void button_delete_varos_Click(object sender, EventArgs e)
        {
            Program.sql.CommandText = "DELETE FROM `varosok` WHERE `id`=@id";
            Program.sql.Parameters.Clear();
            Program.sql.Parameters.AddWithValue("@id", (int)dataGridView_varos.SelectedRows[0].Cells["Id"].Value);
            try
            {
                Program.sql.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            textBox_varosnev.Text = "";
            numericUpDown_varoslakossag.Value = numericUpDown_varoslakossag.Minimum;
            DataGridViewvaros_Tabla_Frissit();
        }

        private void button_deletelatvany_Click(object sender, EventArgs e)
        {

            Program.sql.CommandText = "DELETE FROM `varosok` WHERE `id`=@id";
            Program.sql.Parameters.Clear();
            Program.sql.Parameters.AddWithValue("@id", (int)dataGridView_varos.SelectedRows[0].Cells["Id"].Value);
            try
            {
                Program.sql.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            textBox_varosnev.Text = "";
            numericUpDown_varoslakossag.Value = numericUpDown_varoslakossag.Minimum;
            DataGridViewvaros_Tabla_Frissit();
        }
    }
}
